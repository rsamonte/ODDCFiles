package com.neusoft.oddc.oddc.neusoft;

public class PlaybackList {
    public String MediaURI;
    public int GShockEvent;
    public int FCWEvent;
    public int LDWEvent;
    public int MediaDeleted;
}