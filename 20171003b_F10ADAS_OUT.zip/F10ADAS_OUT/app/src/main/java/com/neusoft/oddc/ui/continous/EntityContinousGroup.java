package com.neusoft.oddc.ui.continous;


import com.neusoft.oddc.widget.expandablerecycler.common.models.ExpandableGroup;

import java.util.List;

public class EntityContinousGroup extends ExpandableGroup {

    public EntityContinousGroup(String title, List<EntityContinousChild> items) {
        super(title, items);
    }


}
