/**
 * Created by yzharchuk on 8/2/2017.
 */

package com.neusoft.oddc.oddc.model;

public enum SpeedDetectionType
{
    TYPE1,
    TYPE2
}