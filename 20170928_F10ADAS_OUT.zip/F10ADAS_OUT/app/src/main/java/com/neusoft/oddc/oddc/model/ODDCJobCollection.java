/**
 * Created by yzharchuk on 8/2/2017.
 */

package com.neusoft.oddc.oddc.model;

import java.util.ArrayList;

/**
 * Created by yzharchuk on 8/2/2017.
 */

public class ODDCJobCollection
{
    private ArrayList<ODDCJob> jobs;

    public ArrayList<ODDCJob> getJobs()
    {
        return jobs;
    }

    public void setJobs(ArrayList<ODDCJob> jobs)
    {
        this.jobs = jobs;
    }
}
