package com.neusoft.oddc.ui.oddcagent;


import com.neusoft.oddc.widget.expandablerecycler.common.models.ExpandableGroup;

import java.util.List;

public class EntityOddcAgentGroup extends ExpandableGroup {

    public EntityOddcAgentGroup(String title, List<String> items) {
        super(title, items);
    }

}
